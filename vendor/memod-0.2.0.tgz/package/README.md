# memod

memod keeps the intent of code in its doc comments and lints for duplicated
logic. Each exported function, class or constant names the concept it owns:

```ts
/**
 * owns: [[kemdash-assistant-turn]]
 * decided: one turn at a time because the model bills per turn
 * premise: 114722+1
 */
export async function runChat(...) {}
```

When two files own the same concept and neither imports the other, memod
reports a duplicate. The agent then reuses the first owner instead of writing
a second copy.

## Set up a repo

1. Add memod as a dev dependency, pinned to a commit. A repo with no
   `package.json` (Rust, Swift, Kotlin, Elixir, Zig) gets one that holds
   only this dependency:

   ```sh
   pnpm add -D "git+https://gitlab.com/joshka0/memod.git#<commit>"
   ```

2. Add the edit hook to `.claude/settings.json`:

   ```json
   { "hooks": { "PostToolUse": [ { "matcher": "Edit|Write|MultiEdit", "hooks": [
     { "type": "command", "command": "cd \"$CLAUDE_PROJECT_DIR\" && node_modules/.bin/memod hook claude" } ] } ] } }
   ```

3. Add the pre-commit line from [Hooks](#hooks).
4. Write in the repo's `AGENTS.md` that the repo uses memod, and that an
   agent runs `memod topics` before it names a topic.
5. Run `node_modules/.bin/memod lint`. It must exit 0 before the first
   commit.

## Tags

| Tag | Where | Meaning |
| --- | --- | --- |
| `owns: [[topic]]` | symbol | The concept this symbol implements. Name the job, not the symbol. |
| `module: [[topic]]` | first doc comment of a file | The file's concept. |
| `boundary: pure` or `boundary: io` | file header | A pure file may import only what `imports:` lists. |
| `imports: a, ./b.ts` | file header | The imports a pure file may use. |
| `decided: <what> because <why>` | symbol or header | A decision and its reason. |
| `premise: 1234+1` | symbol or header | The fleet memo the code rests on. |
| `pre:` and `post:` | symbol | Contract lines. |
| `verified: check-name` | symbol | A formal check in `memod.checks.json` covers this symbol. |

## Lint rules

| Rule | Fires when |
| --- | --- |
| `duplicate-owner` | Two files own one topic and neither imports the other. |
| `untagged-export` | An exported value in a changed file has no `owns` tag. Exported types are exempt. |
| `filler-topic` | A topic in a changed file only repeats the symbol's name, such as `runChat` owning `[[x-chat-run-chat]]`. |
| `stale-premise` | A checked file cites a memo that the fleet memory marks superseded or stale. |
| `stale-verification` | The code of a `verified` symbol changed since its check last passed, or a recorded symbol is gone. |
| `boundary-violation` | A pure file imports something its header does not list. |
| `malformed-tag`, `parse-error` | A tag or the file cannot be read. |

Tests, `.d.ts` files and `dist/`, `build/` and `generated/` output need no tags.

## Languages

| Language | Doc comment | File header | Exported | Linked by |
| --- | --- | --- | --- | --- |
| TypeScript, JavaScript | `/** */` | first doc comment with `module:` | `export` | relative imports |
| Elixir (`.ex`) | `@doc`, or `#` lines | `@moduledoc` of the first module | `def`, `defmacro`, `defguard`, `defdelegate` | a module name that another file defines |
| Kotlin (`.kt`) | `/** */` | first `/** */` with `module:` | not `private` | an imported name that another file declares, or a same-package use |
| Rust | `///` | leading `//!` lines | `pub` in any form | `use crate::`, `self::`, `super::` paths and `mod x;` |
| Swift | `///` | first `///` run with `module:` | not `private` or `fileprivate` | nothing |
| Zig | `///` | leading `//!` lines | `pub` | `@import("x.zig")` |

Lint reads top-level declarations only: no methods of a class, an `impl` or
an `extension`. Rust, Swift, Zig, Elixir and Kotlin are read by line, not
parsed. The Rust and Swift readers also record members, the declarations
inside a container, for `memod graph`, `memod uses` and `memod history`
([ADR 0005](docs/adr/0005-rust-and-swift-members-and-references.md)). A
member is named with its containers:

| Language | Container | Member name |
| --- | --- | --- |
| Rust | `impl Store` | `Store::get` |
| Rust | `impl<T> Wrapper<T>` | `Wrapper<T>::new` (the type as written) |
| Rust | `impl Default for Config` | `<Config as Default>::default` |
| Rust | `trait Store` | `Store::get` |
| Rust | `mod tests { }`, nested | `tests::helper`, `tests::Fake::new` |
| Rust | `extern "C" { }` | `ghostty_new` (the block adds nothing) |
| Swift | a type, protocol or `extension Room` | `Room.join(_:)`, `Room.name`, `Room.init(id:)` |
| Swift | a nested type | `Outer.Inner.reset()` |

A Swift `func`, `init` or `subscript` carries its argument labels, so two
overloads are two members. A member needs no `owns` tag, and lint reads none
of its tags yet: its tags appear in the graph and in `memod history` only. In Kotlin, a data, enum or sealed class needs no topic, and an
extension is named with its receiver (`String.slug`).
In Elixir, the functions of each module are the symbols, one per name. A
function under `@impl` or in a `defimpl` needs no topic. Tag a `defp` in
`#` lines above it, because Elixir discards its `@doc`. `.exs` files are not
read, and an Erlang module (`:crypto`) is not an import.
Swift has no file imports, so two Swift files that own one topic are always
duplicate owners.

A copied app is left out of the index. Mark it in its `package.json` with
`"memod": { "copyOf": "<folder it was copied from>" }`. Its code is owned by
the original: its exports need no tags and do not count as second owners.

## Commands

```sh
memod lint [--base <ref>] [--only <file>...]   # exit 1 on a finding
memod history <file>[:<symbol>]                # commits, tag changes and memos that shaped the code
memod stats                                    # how findings were resolved
memod topics                                   # every topic and its owners
memod verify <check>                           # run a formal check; record the code it covers
memod report                                   # places to abstract
memod view <title> <output>                    # an Archify architecture candidate
memod graph [--history]                        # the code graph as JSON; --history adds commits
memod uses <file>|<topic>                      # every file that depends on it through imports
memod uses <file>:<symbol>                     # every symbol whose code uses it (TypeScript, JavaScript, Rust, Swift)
memod path <from> <to>                         # one shortest import chain between two files
```

`--base` sets the ref that decides which files count as changed (default
`HEAD`). `--only` reports findings in the named files only, and checks them as
changed files. The whole repo is still indexed.

`graph`, `uses` and `path` read the links that lint uses: an import of a file
in the repo, by each language's rule in [Languages](#languages), type-only
imports included. `memod graph` prints `{ "nodes": [...], "edges": [...] }`.
Each node has `id`, `kind` and `name`, and its id is `<kind>:<name>`, except a
decision's. A symbol node also has `line` and `endLine`: the 1-based,
inclusive first and last lines of the span memod hashes as that symbol's
code, so `<file>` at `line` to `endLine` is its own source. The span is the
declaration without its doc comment; a TypeScript or JavaScript decorator
that is part of the statement is inside it (a decorator above an `export`
line is outside), and a Rust `#[...]`, Swift `@...` or Kotlin `@...`
attribute line above the declaration is outside it, as it is outside the
code hash ([ADR 0004](docs/adr/0004-code-changes-by-code-hash.md)).
The amendment to
[ADR 0003](docs/adr/0003-graph-output-contract.md) states the fields. Each
edge has `kind`, `from` and `to`, both node ids. Nodes sort by id, edges by
kind, `from`, `to`, then line and specifier, so the same repo state prints
the same bytes. Other tools read this output:
[ADR 0003](docs/adr/0003-graph-output-contract.md) says what it promises.

| Kind | Node id, or edge `from -> to` | Fields | Meaning |
| --- | --- | --- | --- |
| `file` node | `file:<path>` | | An indexed file. |
| `topic` node | `topic:<slug>` | | A topic that an `owns` tag names. |
| `package` node | `package:<specifier>` | | An import that names no file in the repo. |
| `symbol` node | `symbol:<file>#<symbol>` | `line`, `endLine` | An indexed symbol or member, in every language. `line` and `endLine` are the first and last line of its code, 1-based and inclusive. |
| `decision` node | `decision:<hash>` | `what`, `because` | The text of a `decided` tag. `name` is `<what> because <because>`; the hash is the first 16 hex digits of the SHA-256 of `name`, so equal text is one node. |
| `check` node | `check:<name>` | | A check that a `verified` tag names, listed in `memod.checks.json` or not. |
| `memo` node | `memo:<ref>` | | A memo that a `premise` tag names. |
| `commit` node | `commit:<sha>` | `date`, `subject` | `--history` only: a commit reachable from `HEAD`. `name` is the full id, `date` the author date in strict ISO 8601. |
| `imports` edge | file -> file or package | `specifier`, `line`, `typeOnly`, `samePackageUse` | `from` imports `to`. |
| `owns` edge | file -> topic | `symbols` | Symbols of `from`, in line order, own `to`. |
| `uses` edge | symbol -> symbol | `typeOnly` | The code of `from` names `to` (TypeScript, JavaScript, Rust, Swift). `typeOnly` is always false for Rust and Swift. |
| `decided` edge | symbol or file -> decision | | The doc comment of `from` holds that `decided` tag; a header tag gives the file. |
| `verified` edge | symbol or file -> check | | The doc comment of `from` holds `verified: <check>`. |
| `premise` edge | symbol or file -> memo | | The doc comment of `from` holds `premise: <ref>`. |
| `changes` edge | commit -> file or symbol | | `--history` only: the commit touched file `to` (following renames), or changed the code or tags of symbol `to`, by the rule `memod history <file>:<symbol>` shows. |

`pre:`, `post:`, `module:`, `boundary:` and `imports:` tags give no node or
edge. A comment with a malformed tag gives none either, because lint reads
none of its tags. Without `--history`, `memod graph` reads no git history.
With it, memod reads the history of `HEAD` with three `git log` calls and
parses every version of each file: about 3 s on this repo (47 commits, 629 symbols). A commit changed a symbol's
code when the symbol's code hash (its code without the doc comment) differs
from its hash in each parent of the commit, so adding or deleting a symbol
changes it and a doc-comment edit does not ([ADR 0004](docs/adr/0004-code-changes-by-code-hash.md)).
Tags follow the same rule: a commit changed a symbol's tags when they differ
from its tags in each parent, so on concurrent branches a commit shows only
its own branch's tag changes. `changes` edges reach only
nodes of the current graph, so a deleted file or symbol, and a file memod does
not index (`README.md`), get none. A merge commit is judged against
each parent like any commit: a merge that takes each symbol from one side
gets no edge, and one that resolves a conflict with new code changes that
symbol and the file. In a shallow clone the oldest
commit present counts as the first commit: it changes every file and symbol
it holds. `memod uses` prints one `<distance>  <file>` line per dependent: 1
imports the target directly, n imports it through n-1 other files. For a
topic `[[t]]` (or `t`), the walk starts at the files that own it, listed at
distance 0. `memod path` prints one file per line, each importing the next.
An unknown file or topic, or no chain, exits 1 with a message that names it.

For TypeScript and JavaScript, the graph also has symbol nodes
(`symbol:<file>#<symbol>`, one per indexed symbol) and `uses` edges: the code
of `from` names `to`, through an import (named, default or `ns.member`, also
across `export ... from` and `export *` chains) or within its own file. A
local name that shadows an import gives no edge. `typeOnly` is true when every
use is erased at run time. `memod uses <file>:<symbol>` reads its argument as
`memod history` does and lists the symbols that use it, directly or through
other symbols, with distance. Limits: a call on a value (`client.send()`)
gives no edge, because that needs types; code outside a symbol (top-level
calls, `export default` of an expression, destructured top-level
declarations) and dynamic `import()` give none. Kotlin, Elixir and Zig
symbols have no symbol edges yet: `memod uses` on one exits 1 and says so.
`memod path` stays file-level. How references are stored:
[ADR 0002](docs/adr/0002-symbol-references-in-the-index.md). The argument
`<file>:<symbol>` splits at the first colon after a source file extension, so
`memod uses 'src/store.rs:<Config as Default>::default'` and
`memod uses 'Room.swift:Room.join(_:)'` work.

Rust and Swift symbols and members get `uses` edges from a scan of the code,
resolved when the graph is built
([ADR 0005](docs/adr/0005-rust-and-swift-members-and-references.md)). A use
inside a function body counts for the function. A name left with several
candidates gives no edge. The rules for Rust:

- A name is looked up in the enclosing `fn` bodies, then the module, then its
  `use` entries: aliases, globs and re-exports through `crate::`, `self::`,
  `super::`, crate names (the folder that holds `src/lib.rs`) and `mod x;`
  files.
- `self.x()`, `Self::x` and `Type::x` go to that type's methods: inherent
  first, then trait impls, then trait defaults.
- `v.x()` goes to the methods of `v`'s type when the text states it: a
  parameter, an annotated `let`, a `let` whose initializer has a known type
  (a call's return type, `?` and `unwrap` on `Option` and `Result`, `lock`,
  `clone`, through `Arc`, `Rc`, `Box`), or a struct field.
- When `v`'s type is a trait (`s: &dyn Store`, `Box<dyn Store>`, `impl
  Store`), the call goes to the trait's declaration `Store::get`, never to an
  implementation.
- When `v`'s type is unknown, the call goes to the only method of that name,
  unless the code also calls that name on a type no indexed file declares.

The rules for Swift:

- Every indexed Swift file is one namespace, as a module sees its own
  declarations; a `private` or `fileprivate` declaration is reached only from
  its own file.
- `name(...)` inside a type goes to that type's members first, also those of
  its extensions and of the types it inherits from or conforms to, then to
  free functions, the same file first.
- `Type(...)` goes to the type and to its `init` whose labels match; a nested
  type is reached by its bare name only inside the type around it.
- `x.name(...)` goes by `x`'s type as in Rust, with labels: argument labels
  choose among overloads, and a defaulted parameter and one trailing closure
  may be left out. When `x`'s stated type is a protocol (`let p: P`), the
  call goes to the requirement `P.join(_:)`, never to a conforming type's
  witness.

What the scan cannot know, so it gives no edge: inferred types (closure
parameters, `for` bindings, most chained calls), the implementation or
witness a trait or protocol call dispatches to at run time, calls on a
generic parameter (`fn f<T: Store>(s: T)`, `func f<T: P>(x: T)`: the scan
reads no bounds), overloads chosen by argument types, macro and
procedural-macro expansions, and `#[path]`. Every `#[cfg]` variant is read, so a name declared
in two variants has two candidates and gives no edge. A crate at the
repository root has no folder name, so a `<crate>::` path into it gives no
edge.

The scan has a cost. Measured on herdr and yada (CPU, paired runs): the edit
hook on one edited file costs +76 ms for Rust and +60 ms for Swift, mostly
the larger index cache; a cold index, once per worktree or after an upgrade,
costs +264 ms for 126 Rust files and +133 ms for 170 Swift files. `memod
graph` resolves the references on each run, about 0.2 s for those Rust
files ([ADR 0005](docs/adr/0005-rust-and-swift-members-and-references.md)).

## Hooks

In Claude Code, add a PostToolUse hook for `Edit|Write|MultiEdit` that runs
`node_modules/.bin/memod hook claude` in the project folder. It only advises.

When an export needs a topic, both hooks print the steps to choose one: read
`memod topics`, and share a topic only with an export that does the same job.
Without these steps an agent names the symbol in its own folder, and no
duplicate is found.

To block a commit on a finding, add this line to `.git/hooks/pre-commit`:

```sh
node_modules/.bin/memod hook pre-commit || exit 1
```

## Formal checks

A formal check, such as a Quint model, covers named code. Tag each covered
symbol with `verified: <check>`, and give the check a command in
`memod.checks.json`:

```json
{ "verify-event-log": { "run": "quint/event-log/check.sh", "covered": {} } }
```

`memod verify verify-event-log` runs the command. When it passes, memod
writes a hash of each covered symbol's code into `covered`. Lint then reports
`stale-verification` when that code changes, so the edit hook tells the agent
to run the check again. A changed doc comment needs no new run. Commit the
manifest with the code change.

## Event log

Each lint run appends one event to `<git common dir>/memod/events.jsonl`. All
worktrees of a clone share the log, and each event carries its worktree's id.
`memod stats` counts each fix once. `quint/event-log/check.sh` checks that
promise (see `.claude/skills/verify-event-log/SKILL.md`). Set
`MEMOD_OTLP_ENDPOINT` to also send one span per run.

Each worktree keeps its own index cache and lint lock in `<git dir>/memod/`.
A run reparses only the files git reports as modified or untracked.

## Develop

```sh
pnpm install
pnpm test
pnpm build      # tsrs to dist/
```
